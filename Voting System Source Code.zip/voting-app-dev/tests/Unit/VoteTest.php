<?php

namespace Tests\Unit;

// use PHPUnit\Framework\TestCase;

use App\Models\Vote;
use App\Models\Voting;
use Tests\TestCase;

use Illuminate\Foundation\Testing\RefreshDatabase;


class VoteTest extends TestCase
{
    // use RefreshDatabase;
    /**
     * A basic test example.
     *
     * @return void
     */
    public function testShowDahsboard()
    {
        $response = $this->get('/');
        $response->assertStatus(200);
        $response->assertSeeText('dashboard');
    }

    public function testVoting()
    {
        $response = $this->post('/show/1', [
            'candidates' => [
                1,
                2
            ]
        ]);
        $response->assertStatus(200);
        $vote = Vote::latest('id')->first();

        $this->assertDatabaseHas('candidate_vote', [
            'vote_id' => $vote->id,
            'candidate_id' => 1
        ]);
        $this->assertDatabaseHas('candidate_vote', [
            'vote_id' => $vote->id,
            'candidate_id' => 2
        ]);
    }
}
