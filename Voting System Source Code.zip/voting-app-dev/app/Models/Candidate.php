<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Candidate extends Model
{
    protected $fillable = [
        'name',
        'voting_id'
    ];

    public function voting()
    {
        return $this->belongsTo(Voting::class);
    }

    public function votes()
    {
        return $this->belongsToMany(Vote::class)->withTimestamps();
    }
}
