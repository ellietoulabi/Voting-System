<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Voting extends Model
{
    protected $fillable = [
        'title',
        'start_date',
        'end_date',
        'visibility',
        'person_id',
        'multican'
    ];

    public function addVote($user, $candidates)
    {
        $v = new Vote();
        $v->person_id = $user;
        $v->voting_id = $this->id;
        $v->save();
        $v->candidates()->sync($candidates);
    }

    public function votes()
    {
        return $this->hasMany(Vote::class);
    }

    public function candidates()
    {
        return $this->hasMany(Candidate::class);
    }

    public function PersianStartDate()
    {
        return \Morilog\Jalali\Jalalian::forge($this->start_date)->format('%A , %d %B %Y');
    }

    public function PersianEndDate()
    {
        return \Morilog\Jalali\Jalalian::forge($this->end_date)->format('%A , %d %B %Y');
    }

    public function PersianStartTime()
    {
        return \Morilog\Jalali\Jalalian::forge($this->start_date)->format('%I:%M:%S');
    }

    public function PersianEndTime()
    {
        return \Morilog\Jalali\Jalalian::forge($this->end_date)->format('%I:%M:%S');
    }

    public function PersianStart()
    {
        return \Morilog\Jalali\Jalalian::forge($this->start_date)->format('%A , %d %B %Y ساعت %I:%M:%S');
    }

    public function PersianEnd()
    {
        return \Morilog\Jalali\Jalalian::forge($this->end_date)->format('%A , %d %B %Y ساعت %I:%M:%S');
    }
}
