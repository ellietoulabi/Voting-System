<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Vote extends Model
{
    protected $fillable = [
        'person_id',
        'voting_id'
    ];

    public function voting()
    {
        return $this->belongsTo(Voting::class);
    }

    public function person()
    {
        return $this->belongsTo(Person::class);
    }

    public function candidates()
    {
        return $this->belongsToMany(Candidate::class)->withTimestamps();
    }
}
