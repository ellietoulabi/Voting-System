<?php

namespace App\Http\Controllers;

use App\Models\Person;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function register_show()
    {
        return view('auth.register');
    }

    public function register_do(Request $request)
    {
        $data = $request->only(['firstname', 'lastname', 'gender', 'username', 'password', 'password_repeat']);
        $validator = Validator::make(
            $data,
            [
                'username' => 'required|unique:people,username',
                'password' => 'required|alpha_num|min:6',
                'password_repeat' => 'required|same:password'
            ],
            $messages = [
                'required' => 'فیلد :attribute اجباری است.',
                'unique' => 'این نام کاربری قبلا انتخاب شده است.',
                'min' => 'حداقل تعداد مجاز برای گذرواژه ۶ کاراکتر است',
                'same' => 'گذرواژه و تکرار آن باید یکسان باشند.'
            ]
        );
        if ($validator->fails()) {
            return redirect()->route('auth.register.show')->withErrors($validator);
        }

        $user = new Person($data);
        $user->password = Hash::make($data['password']);
        $user->is_admin = false;
        $user->save();

        return redirect()->route('auth.login.show')->with('msg', 'حساب شما با موفقیت ساخته شد. هم اکنون میتوانید وارد شوید.');
    }

    public function login_show()
    {
        return view('auth.login');
    }

    public function login_do(Request $request)
    {
        $data = $request->validate([
            'username' => 'required',
            'password' => 'required'
        ]);

        if (Auth::attempt($data)) {
            if (Auth::user()->is_admin) {
                if ($request->has('after')) {
                    return redirect($request->get('after'));
                }
                return redirect()->route('admin.dashboard');
            } else {
                if ($request->has('after')) {
                    return redirect($request->get('after'));
                }
                return redirect()->route('user.dashboard');
            }
        }

        return redirect()->route('auth.login.show')->withErrors('اطاعات ورود نادرست است.');
    }

    public function logout(Request $request)
    {
        Auth::logout();
        return redirect()->route('auth.login.show')->with('msg', 'شما با موفقیت از حساب کاربری خود خارج شدید.');
    }
}
