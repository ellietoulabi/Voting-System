<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Candidate;
use App\Models\Voting;
use Illuminate\Http\Request;
use Morilog\Jalali\Jalalian;
class VotingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $active_votings = Voting::where('end_date', '>', now())->get();
        return view('admin.activevotingsList', ['votings' => $active_votings]);
    }

    public function active()
    {

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.voting_create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {


        $sdate = new Jalalian($request->start_date_year, $request->start_date_month, $request->start_date_day);
        $edate = new Jalalian($request->end_date_year, $request->end_date_month, $request->end_date_day);


        $title = $request->title;
        $s_date = $sdate->toCarbon();;
        $e_date = $edate->toCarbon();;
        $visibility = ($request->visibility === "on") ? true : false;
        $multican = ($request->multican === "on") ? true : false;
        $person_id = 1;
        $candidates = $request->candidates;

        $v = new Voting();
        $v->title = $title;
        $v->start_date = $s_date;
        $v->end_date = $e_date;
        $v->visibility = $visibility;
        $v->multican = $multican;
        $v->person_id = $person_id;
        $v->save();

        foreach ($candidates as $candidate) {
            $c = new Candidate();
            $c->name = $candidate;
            $c->voting_id = $v->id;
            $c->save();
        }

        return redirect()->route('admin.voting.create')->with('msg', 'رای گیری شما با موفقیت ثبت شد.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Voting  $voting
     * @return \Illuminate\Http\Response
     */
    public function show(Voting $voting)
    {
        return view('admin.voting_show', ['voting' => $voting]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Voting  $voting
     * @return \Illuminate\Http\Response
     */
    public function edit(Voting $voting)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Voting  $voting
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Voting $voting)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Voting  $voting
     * @return \Illuminate\Http\Response
     */
    public function destroy(Voting $voting)
    {
        $voting->delete();
        return redirect()->route('admin.voting.index')->with('msg', 'رای گیری با موفقیت حذف شد.');
    }


    public function show_result(Voting $voting)
    {
        $votes = $voting->votes->all();
        return view('admin.voting_result', ['voting' => $voting, 'votes' => $votes]);
    }
}
