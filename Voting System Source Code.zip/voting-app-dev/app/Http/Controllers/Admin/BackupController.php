<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;

class BackupController extends Controller
{
    public function show()
    {
        return view('admin.backup');
    }

    public function do(Request $request)
    {
        Artisan::call('backup:run');
        return redirect()->route('admin.backup.show')->with('msg', 'بک آپ با موفقیت تهیه شد');
    }
}
