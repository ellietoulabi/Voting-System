<?php

namespace App\Http\Controllers\User;

use App\Models\Voting;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class VotingController extends Controller
{
    public function index()
    {
        return view('auth.register');
    }

    public function active()
    {
        $active_votings = Voting::where('start_date', '<=', now())
            ->Where('end_date', '>', now())->get();
        return view('user.activevotingsList', ['votings' => $active_votings]);
    }

    public function show(Voting $voting)
    {
        if ($voting->votes()->where('person_id', Auth::user()->id)->count() > 0) {
            return redirect()->route('user.voting.active')->with('err', 'شما قبلا در این رای گیری شرکت کرده اید.');
        }

        return view('user.showvoting', ['voting' => $voting]);
    }

    public function store(Request $request, Voting $voting)
    {
        $user_id = Auth::user()->id;
        $candidates = $request->candidates;
        $voting->addVote($user_id, $candidates);

        return redirect()->route('user.voting.active')->with('msg', 'رای شما با موفقیت ثبت شد.');
    }

    public function show_result(Voting $voting)
    {
        $user_id = Auth::user()->id;
        $vote = $voting->votes->where('person_id', '=', $user_id)->first();
        return view('user.voting_result', ['voting' => $voting, 'vote' => $vote]);
    }

    public function result_list()
    {
        $votings = Voting::where('visibility', true)->get();
        return view('user.resultvotinglist', ['votings' => $votings]);
    }
}
