<?php

namespace App\Console\Commands;

use App\Models\Candidate;
use App\Models\Person;
use App\Models\Voting;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Hash;

class FillDatabase extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'fill:db';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        Person::create(
            [
                'firstname' => 'علی',
                'lastname' => 'حسنی',
                'username' => 'ali',
                'password' => Hash::make('1234'),
                'gender' => 'Male',
                'is_admin' => true
            ]
        );
        Person::create(
            [
                'firstname' => 'رضا',
                'lastname' => 'کریمی',
                'username' => 'reza',
                'password' => Hash::make('4321'),
                'gender' => 'Male',
                'is_admin' => false
            ]
        );
        $this->info('Users created');

        Voting::create([
            'title' => 'رای گیری شماره 1',
            'start_date' => Carbon::yesterday(),
            'end_date' => Carbon::createFromDate(2021, 7, 12),
            'visibility' => false,
            'person_id' => 1
        ]);
        $this->info('Voting created');

        Candidate::insert([
            [
                'name' => 'کریم رضایی',
                'voting_id' => 1
            ],
            [
                'name' => 'سروش احمدی',
                'voting_id' => 1
            ],
            [
                'name' => 'مرجان گلچین',
                'voting_id' => 1
            ],
            [
                'name' => 'حمید حقیقت دوست',
                'voting_id' => 1
            ],
            [
                'name' => 'اکبر تقیان',
                'voting_id' => 1
            ],
        ]);
        $this->info('Candidates created');

        return 0;
    }
}
