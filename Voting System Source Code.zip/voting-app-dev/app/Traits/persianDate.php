<!-- <?php

namespace AppTraits;

// use MorilogJalaliJalalian;

// trait PersianDate
// {
//     public function PersianStart($format = '%A, %d %B %y')
//     {
//         return Jalalian::forge($this->created_at)->format($format);
//     }

//     public function PersianEnd($format = '%A, %d %B %y')
//     {
//         return Jalalian::forge($this->created_at)->format($format);
//     }
// }
