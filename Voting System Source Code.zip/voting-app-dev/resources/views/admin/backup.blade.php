@extends('admin.layout')

@section('level1')
بک آپ
@endsection
@section('listActive')
'disabled'
@endsection
@section('dashActive')
    'disabled'
@endsection
@section('content')
@if(Session::has('msg'))
    <div class="alert alert-success">
        {{Session::get('msg')}}
    </div>
    @endif
{{-- <div class="row "> --}}
    <div class="heading" style="margin-bottom: 58px;">
        <h2>ایجاد بک آپ</h2>
    </div>
<form method='POST' action="{{route('admin.backup.do')}}" style="background: #ffffff;padding: 50px;max-width: 42rem;margin-top: 0px;padding-bottom: 13px;">

        <div id="frm1">
            {{-- <h4 class="text-center">ایجاد رای گیری</h5> --}}


            <label for="vTitle" class="col-12 col-form-label">با کلیک بر روی دکمه زیر یک بک آپ از سیستم تهیه میشود.</label>





            <div class="form-group" style="margin-top: 56px;">
                <div class="form-row d-flex flex-row-reverse">
                    <div class="col-12"><button class="btn btn-outline-success btn-block" type="submit" style="border-radius: 6px;" >ایجاد بک آپ</button></div>
                </div>
            </div>
        </div>

    </form>


{{-- </div> --}}
@endsection
