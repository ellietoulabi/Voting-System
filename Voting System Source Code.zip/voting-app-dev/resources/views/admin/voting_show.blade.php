@extends('admin.layout')

@section('level1')
ایجاد را گیری
@endsection
@section('listActive')
'disabled'
@endsection
@section('dashActive')
    'disabled'
@endsection
@section('content')
@if(Session::has('msg'))
    <div class="alert alert-success">
        {{Session::get('msg')}}
    </div>
    @endif
{{-- <div class="row "> --}}
    <div class="heading" style="margin-bottom: 58px;">
        <h2>مشاهده رای گیری</h2>
    </div>
<form method='POST' action="{{route('admin.voting.destroy', $voting)}}" style="background: #ffffff;padding: 50px;max-width: 42rem;margin-top: 0px;padding-bottom: 13px;">

        <div id="frm1">
            {{-- <h4 class="text-center">ایجاد رای گیری</h5> --}}


            <label for="vTitle" class="col-12 col-form-label">عنوان</label>
            <div class="">
                <input disabled class="form-control" type="text" name="title" value="{{$voting->title}}" id="vTitle">
            </div>

            <div class="row">
                <div class="form-group col-6 pt-2{{--row--}}">
                    <label for="startDateTime" class="col-2 col-form-label">شروع</label>
                    <div class="">
                      <input class="form-control" disabled value="{{$voting->PersianStartDate()}}" type="text" name="start_date"  id="startDateTime">
                    </div>
                </div>

                <div class="form-group col-6  pt-2{{--row--}}">
                    <label for="endDateTime" class="col-2 col-form-label">اتمام</label>
                    <div class="">
                        <input class="form-control" disabled value="{{$voting->PersianEndDate()}}" name="end_date" type="text" id="endDateTime">
                    </div>
                </div>
            </div>

            <h5 class="mt-5">لیست کاندیدا ها </h4>

            <ul>
                @foreach ($voting->candidates as $candidate)
                    <li>{{$candidate->name}}</li>
                @endforeach
            </ul>




            <div class="form-group">
                <div class="form-row">
                    <div class="col">
                        <div style="padding: 9px;border-top: 0.4px solid rgba(191,191,191,0.31) ;">
                        <div class="form-check"><input class="form-check-input" @if($voting->visibility) checked @endif type="checkbox" id="visibleResult" disabled name="visibility"  ><label class="form-check-label" for="visibleResult">نتایج رای گیری برای عموم قابل مشاهده باشند.</label></div>
                            <div class="form-check"><input class="form-check-input" @if($voting->multican) checked @endif type="checkbox" id="multipleCand" disabled name="multican"  ><label class="form-check-label" for="multipleCand">قابلیت انتخاب چند کاندیدا وجود دارد.</label></div>
                        </div>
                    </div>
                </div>
            </div>





            <div class="form-group" style="margin-top: 56px;">
                <div class="form-row d-flex flex-row-reverse">
                <div class="col-3"><a href="{{route('admin.voting.result', $voting)}}" class="btn btn-outline-success btn-block" type="submit" style="border-radius: 6px;" >مشاهده نتیجه</a></div>
                    <input type="hidden" name="_method" value="delete" />
                    <div class="col-3"><input class="btn btn-block btn-danger-custom" value="حذف" name="delete"  type="submit" style="border-radius: 6px;"></div>
                </div>
            </div>
            <div class="alert alert-danger pulse animated" role="alert" id="errAlert" style="display: none;"><span><strong>لطفا یک یا چند کاندیدا را انتخاب کنید.</strong></span></div>
        </div>

    </form>


{{-- </div> --}}
@endsection
