@extends('admin.layout')

@section('level1')
رای گیری های فعال
@endsection
@section('level2')
{{$voting->title}}
@endsection

@section('content')


<div class="container">
    
    <div class="heading" style="margin-bottom: 58px;">
        <h2>{{$voting->title}}</h2>
    </div>
    <div style="background: #ffffff;padding: 50px;margin: auto;padding-bottom: 13px;">
        <h5>نتایج این رای گیری:</h5>
        <div class="form-group">
            <div class="form-row" style="background-color: #ddd; border-bottom: 1px solid #333;">
                <div class="col-6">
                    <div>نام کاندیدا</div>
                </div>
                <div class="col-6">
                    <div>تعداد رای</div>
                </div>
            </div>
        </div>
        @foreach ($voting->candidates as $candidate)
        <div class="form-group">
            <div class="form-row">
                <div class="col-6">
                    <div>{{ $candidate->name }}</div>
                </div>
                <div class="col-6">
                    <div>{{ $candidate->votes()->count() }}</div>
                </div>
            </div>
        </div>
        @endforeach
    </div>

    @endsection

