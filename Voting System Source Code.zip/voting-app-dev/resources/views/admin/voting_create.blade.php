@extends('admin.layout')

@section('level1')
ایجاد را گیری
@endsection
@section('listActive')
'disabled'
@endsection
@section('dashActive')
    'disabled'
@endsection
@section('content')
@if(Session::has('msg'))
    <div class="alert alert-success">
        {{Session::get('msg')}}
    </div>
    @endif
{{-- <div class="row "> --}}
    <div class="heading" style="margin-bottom: 58px;">
        <h2>ایجاد رای گیری</h2>
    </div>
<form method='POST' action="{{route('admin.voting.store')}}" style="background: #ffffff;padding: 50px;max-width: 42rem;margin-top: 0px;padding-bottom: 13px;">

        <div id="frm1">
            {{-- <h4 class="text-center">ایجاد رای گیری</h5> --}}


            <label for="vTitle" class="col-2 col-form-label">عنوان</label>
            <div class="">
                <input class="form-control" type="text" name="title" id="vTitle">
            </div>

            <div class="row">
                <div class="form-group col-6 pt-2{{--row--}}">
                    <label for="startDateTime" class="col-2 col-form-label">شروع</label>
                    <div style="display: flex">
                      <input placeholder="روز" class="form-control col-2" type="text" name="start_date_day"  id="startDateTime">
                      <span class="p-2">/</span>
                      <input placeholder="ماه" class="form-control col-2" type="text" name="start_date_month"  id="startDateTime">
                     <span class="p-2">/</span>
                     <input placeholder="سال" class="form-control col-4" type="text" name="start_date_year"  id="startDateTime">

                    </div>
                </div>

                <div class="form-group col-6 pt-2 {{--row--}}">
                    <label for="endDateTime" class="col-2 col-form-label">اتمام</label>
                    <div style="display: flex">
                        <input placeholder="روز" class="form-control col-2" type="text" name="end_date_day"  id="endDateTime">
                        <span class="p-2">/</span>
                        <input placeholder="ماه" class="form-control col-2" type="text" name="end_date_month"  id="endDateTime">
                       <span class="p-2">/</span>
                       <input placeholder="سال" class="form-control col-4" type="text" name="end_date_year"  id="endDateTime">

                      </div>
                </div>
            </div>

            <h5 class="mt-5">لیست کاندیدا ها </h4>

            <div class="form-group input-group can-row">

                <input type="text" class="form-control" name="candidates[]" placeholder="نام و نام خانوادگی"></input>

                <div class="form-group pl-1 pr-1">
                    <a class="btn btn-success btn-sm addCanBtn">
                        {{-- <i class="ti-trash"> </i> --}}
                        افزودن
                    </a>

                </div>
                <div class="form-group ">
                    <a class="btn btn-danger btn-sm delCanBtn">
                        {{-- <i class="ti-trash"> </i> --}}
                        حذف
                    </a>
                </div>
            </div>





            <div class="form-group">
                <div class="form-row">
                    <div class="col">
                        <div style="padding: 9px;border-top: 0.4px solid rgba(191,191,191,0.31) ;">
                            <div class="form-check"><input class="form-check-input" type="checkbox" id="visibleResult" name="visibility"  ><label class="form-check-label" for="visibleResult">نتایج رای گیری برای عموم قابل مشاهده باشند.</label></div>
                            <div class="form-check"><input class="form-check-input" type="checkbox" id="multipleCand" name="multican"  ><label class="form-check-label" for="multipleCand">قابلیت انتخاب چند کاندیدا وجود دارد.</label></div>
                        </div>
                    </div>
                </div>
            </div>





            <div class="form-group" style="margin-top: 56px;">
                <div class="form-row d-flex flex-row-reverse">
                    <div class="col-3"><button class="btn btn-outline-success btn-block" type="submit" style="border-radius: 6px;" >ایجاد</button></div>
                    <div class="col-3"><a class="btn btn-block btn-danger-custom" href="{{route('user.voting.active')}}" type="button" style="border-radius: 6px;">انصراف</a></div>
                </div>
            </div>
            <div class="alert alert-danger pulse animated" role="alert" id="errAlert" style="display: none;"><span><strong>لطفا یک یا چند کاندیدا را انتخاب کنید.</strong></span></div>
        </div>

    </form>


{{-- </div> --}}
@endsection
