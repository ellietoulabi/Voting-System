@extends('admin.layout')

@section('level1')
رای گیری های فعال
@endsection
@section('listActive')
'disabled'
@endsection
@section('dashActive')
    'disabled'
@endsection
@section('content')
@if(Session::has('msg'))
    <div class="alert alert-success">
        {{Session::get('msg')}}
    </div>
    @endif

    <div class="heading" style="margin-bottom: 58px;">
        <h2> رای گیری های فعال</h2>
    </div>

    <div  style="background: #ffffff;padding: 50px;max-width: 70rem;margin-top: 0px;padding-bottom: 13px;">
        <div class="list-group ">
        @foreach ($votings as $voting)

        <div class="card list-group-item list-group-item-action"style="border-radius: 4px;background: #fff; box-shadow: 0 6px 10px rgba(0,0,0,.08), 0 0 6px rgba(0,0,0,.05);transition: .3s transform cubic-bezier(.155,1.105,.295,1.12),.3s box-shadow,.3s -webkit-transform cubic-bezier(.155,1.105,.295,1.12);padding: 10px 80px 12px 36px;">
            <div class="card-body">
                <h5 class="card-title">عنوان: {{$voting->title}}</h5>
                <p class="card-text">

                <span class="pull-right pl-3">تاریخ شروع: {{$voting->PersianStart()}} </span>
                <span class="pull-right">تاریخ پایان:{{$voting->PersianEnd()}}</span>
                <div class="pull-left">

                    <a class="btn btn-outline-success btn-sm ml-2" role="button" href="{{route('admin.voting.show',[$voting])}}" style="border-radius: 5px;">مشاهده</a>
                    {{-- <a class="btn btn-outline-success btn-sm" role="button" href="{{route('admin.voting.edit',[$voting])}}" style="border-radius: 5px;">ویرایش</a> --}}
                    {{-- @if(\Carbon\Carbon::parse(strtotime($voting->start_date))->gt(date('Y-m-d', strtotime("+2 days"))))
                        <a class="btn btn-outline-info btn-sm" role="button" href="{{route('user.voting.show',[$voting])}}" style="border-radius: 5px;">ویرایش</a>
                    @else
                        <a class="btn btn-outline-info btn-sm disabled" role="button" href="{{route('user.voting.show',[$voting])}}" style="border-radius: 5px;">ویرایش</a>
                    @endif --}}
                    @if(\Carbon\Carbon::parse(strtotime($voting->start_date))->gt(date('Y-m-d', strtotime("+2 days"))))
                        <a class="btn btn-outline-danger btn-sm" role="button" href="{{route('admin.voting.index')}}" style="border-radius: 5px;">حذف</a>
                    @else
                        <form style="float: left; padding: initial; max-width: initial; margin: initial; box-shadow: initial;" method="post" action="{{route('admin.voting.destroy', ['voting' => $voting])}}">
                            <input type="hidden" name="_method" value="delete" />
                            <button type="submit" class="btn btn-outline-danger btn-sm" role="button" href="" style="border-radius: 5px;">حذف</button>
                        </form>
                    @endif
                    </div>
                </p>

            </div>
        </div>
        @endforeach
        </div>
    </div>

@endsection
