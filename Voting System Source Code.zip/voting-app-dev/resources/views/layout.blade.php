<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>سیستم رای گیری الکترونیکی</title>
    <link rel="stylesheet" href="/assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:300,400,700">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:400,700">
    <link rel="stylesheet" href="/assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="/assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="/assets/css/Footer-Clean.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/pikaday/1.6.1/css/pikaday.min.css">
    <link rel="stylesheet" href="/assets/css/Navigation-with-Button.css">
    <link rel="stylesheet" href="/assets/css/PJansari---Horizontal-Stepper.css">
    <link rel="stylesheet" href="/assets/css/Steps-Progressbar.css">
    <link rel="stylesheet" href="/assets/css/untitled.css">
</head>

<body style="background: rgb(243,245,251);font-family: yekan;direction: rtl;text-align: right;">
    <nav class="navbar navbar-dark navbar-expand-lg bg-white portfolio-navbar gradient" style="height: 259px;background: linear-gradient(149deg, rgb(100,179,241) 0%, rgb(99,179,103));">
        <div class="container"><a class="navbar-brand logo" href="#">سامانه رای گیری الکترونیکی</a></div>
    </nav>
    <nav class="navbar navbar-light navbar-expand-md navigation-clean-button" style="height: 59px;">
        <div class="container"><button data-toggle="collapse" class="navbar-toggler" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navcol-1" style="direction: rtl;">
                <ul class="nav navbar-nav mr-auto" style="margin-left: auto;margin-right: 0px!important;height: 56px;">
                    <li class="nav-item"><a class="nav-link {{ ( Route::currentRouteName()=='index') ? 'active' : '' }}" href="{{route('index') }}">داشبورد</a></li>
                    <li class="nav-item"><a class="nav-link disabled" href="#">مشاهده نتایج رای گیری ها</a></li>
                    <li class="nav-item"><a class="nav-link {{ ( Route::currentRouteName()=='active') ? 'active' : '' }} href="{{route('user.voting.active') }}">رای گیری های فعال</a></li>
                </ul><span class="navbar-text actions"> <a class="btn d-xl-flex justify-content-xl-end align-items-xl-center action-button" role="button" href="#" style="border-radius: 10px;border-color: rgb(0,0,0);background-color: transparent;color: #000;"><i class="fa fa-external-link"></i>&nbsp; خروج</a></span></div>
        </div>
    </nav>
    <main class="page hire-me-page">
        <section class="portfolio-block hire-me" style="padding: 21px;">
            <ol class="breadcrumb" style="direction: rtl;background: rgb(233,236,239);">
                <li class="breadcrumb-item"><a href="{{route('index') }}"><span>داشبورد</span></a></li>
                <li class="breadcrumb-item"><a href="{{route('user.voting.active') }}"><span>@yield('level1')</span></a></li>
                <li class="breadcrumb-item"><a href="#"><span>@yield('level2')</span></a></li>
            </ol>

            <div class="container">@yield('content')</div>
        </section>
    </main>
    <div class="footer-clean  ">
        <footer >
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-sm-4 col-md-3 item">
                        <h3>خدمات</h3>
                        <ul>
                            <li><a href="#">سیستم های رای گیری</a></li>
                            <li><a href="#">سامانه انتخابات اختصاصی</a></li>
                            <li><a href="#">سرویس های عمومی</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-4 col-md-3 item">
                        <h3>درباره ما</h3>
                        <ul>
                            <li><a href="#">درباره ما</a></li>
                            <li><a href="#">تیم&nbsp;</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-4 col-md-3 item">
                        <h3>همکاری با ما</h3>
                        <ul>
                            <li><a href="#">موقعیت های شغلی</a></li>
                            <li><a href="#">فرهنگ کاری</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-3 item social"><a href="#"><i class="icon ion-social-facebook"></i></a><a href="#"><i class="icon ion-social-twitter"></i></a><a href="#"><i class="icon ion-social-github"></i></a><a href="#"><i class="icon ion-social-instagram"></i></a>
                        <p class="copyright">کلیه حقوق متعلق به برند میباشد.</p>
                    </div>
                </div>
            </div>
        </footer>
    </div>
    <script src="/assets/js/jquery.min.js"></script>
    <script src="/assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pikaday/1.6.1/pikaday.min.js"></script>
    <script src="/assets/js/theme.js"></script>
</body>

</html>
