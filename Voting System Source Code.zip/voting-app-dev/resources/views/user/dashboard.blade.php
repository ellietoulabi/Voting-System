@extends('user.layout')

@section('level1')
پنل کاربری
@endsection
@section('listActive')
'disabled'
@endsection
@section('dashActive')
    'disabled'
@endsection
@section('content')
    @if(Session::has('msg'))
    <div class="alert alert-success">
        {{Session::get('msg')}}
    </div>
    @else
    <div class="alert alert-success" role="alert">
        <span><strong>
            <span>{{auth()->user()->firstname}}</span>
            <span>{{ auth()->user()->lastname}}</span>
            ، به پنل کاربری خوش آمدید.
        </strong></span>
    </div>
    @endif



@endsection
