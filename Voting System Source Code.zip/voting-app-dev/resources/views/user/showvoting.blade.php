@extends('user.layout')

@section('level1')
رای گیری های فعال
@endsection
@section('level2')
{{$voting->title}}
@endsection

@section('content')


<div class="container">
    <div class="heading" style="margin-bottom: 58px;">
        <h2>{{$voting->title}}</h2>
    </div>
    <form method='POST' action="{{route('user.voting.store',[$voting])}}" style="background: #ffffff;padding: 50px;max-width: 35rem;margin-top: 0px;padding-bottom: 13px;">
        <div class="form-row" style="margin-top: -90px;margin-bottom: 37px;">
            <div class="col-6 d-flex justify-content-center flex-column align-items-center"><span>انتخاب کاندیداها</span>
                <div id="step1c" class="d-flex justify-content-center align-items-center active-nav-c" style="width: 35px;height: 35px;background: #c9cbc9;border-radius: 100%;"><i class="fa fa-check-square-o"></i></div>
            </div>
            <div class="col-6 d-flex justify-content-center flex-column align-items-center"><span>تایید</span>
                <div id="step2c" class="d-flex justify-content-center align-items-center passive-nav-c" style="width: 35px;height: 35px;background: #c9cbc9;border-radius: 100%;"><i class="fa fa-check-square-o"></i></div>
            </div>
        </div>
        <div id="frm1">
            <h5>کاندیدا یا کاندیداهای موردنظر خود را انتخاب کنید.</h5>
            @php
                $tp = ($voting->multican)? 'checkbox' : 'radio';
            @endphp
            @foreach ($voting->candidates as $candidate)
            <div class="form-group">
                <div class="form-row">
                    <div class="col">
                        <div style="padding: 9px;border-bottom: 0.4px solid rgba(191,191,191,0.31) ;">
                        <div class="form-check"><input class="form-check-input" type="{{$tp}}" id="formCheck-{{$candidate->id}}" name="candidates[]" value="{{$candidate->id}}" data-v="{{$candidate->name}}"><label class="form-check-label" for="formCheck-{{$candidate->id}}">{{$candidate->name }}</label></div>
                        </div>
                    </div>
                </div>
            </div>

            @endforeach



            <div class="form-group" style="margin-top: 56px;">
                <div class="form-row d-flex flex-row-reverse">
                    <div class="col-3"><button class="btn btn-outline-success btn-block" id="step1btn" type="button" style="border-radius: 6px;" data-toggle="modal" data-target="#confModal">ثبت آرا</button></div>
                    <div class="col-3"><a class="btn btn-block btn-danger-custom" href="{{route('user.voting.active')}}" type="button" style="border-radius: 6px;">انصراف</a></div>
                </div>
            </div>
            <div class="alert alert-danger pulse animated" role="alert" id="errAlert" style="display: none;"><span><strong>لطفا یک یا چند کاندیدا را انتخاب کنید.</strong></span></div>
        </div>
        <div id="frm2" style="display: none;">
            <h5>آیا از لیست کاندیداهای برگزیده خود اطمینان دارید؟</h5>
            <div id="frm2c"></div>
            <div class="form-group" style="margin-top: 56px;">
                <div class="form-row d-flex flex-row-reverse">
                    <div class="col-3"><button class="btn btn-outline-success btn-block" id="step1btn-1" type="submit" style="border-radius: 6px;" data-toggle="modal" data-target="#confModal">تایید</button></div>
                    <div class="col-5"><button class="btn btn-block btn-danger-custom" id="backBtn" type="button" style="border-radius: 6px;" data-toggle="modal" data-target="#confModal">بازگشت به رای گیری</button></div>
                </div>
            </div>
        </div>
    </form>

    @endsection

