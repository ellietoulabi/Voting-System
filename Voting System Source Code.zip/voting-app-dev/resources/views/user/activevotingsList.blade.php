@extends('user.layout')

@section('level1')
رای گیری های فعال
@endsection
@section('listActive')

@endsection
@section('dashActive')
    'disabled'
@endsection
@section('content')
@if(Session::has('msg'))
    <div class="alert alert-success">
        {{Session::get('msg')}}
    </div>
@endif
@if(Session::has('err'))
    <div class="alert alert-danger">
        {{Session::get('err')}}
    </div>
@endif
<div class="row d-flex justify-content-center">

    @foreach ($votings as $voting)

    <div class="col-6">
        <div class="project-card-no-image">
        <h3>{{$voting->title}}</h3>
            {{-- <h4>تاریخ شروع: {{$voting->start_date}}-</h4> --}}
            <h4>تاریخ شروع:  {{$voting->PersianStartDate()}} </h4>
            {{-- <h4>زمان شروع:  {{$voting->PersianStartTime()}} </h4> --}}
            <h4>تاریخ پایان: {{$voting->PersianEndDate()}}</h4>
            {{-- <h4>زمان پایان: {{$voting->PersianEndTime()}}</h4> --}}


            {{-- <h4>تاریخ پایان: {{$voting->end_date}}</h4> --}}
            @if ($voting->votes()->where('person_id', Auth::user()->id)->count())
            @else
            <a class="btn btn-outline-success btn-sm" role="button" href="{{route('user.voting.show',[$voting])}}" style="border-radius: 5px;">شرکت در رای گیری</a>
            @endif
        </div>
    </div>

    @endforeach


</div>
@endsection
