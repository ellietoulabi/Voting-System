@extends('user.layout')

@section('level1')
مشاهده نتیج رای گیری ها
@endsection
@section('level2')
{{$voting->title}}
@endsection

@section('content')


<div class="container">

    <div class="heading" style="margin-bottom: 58px;">
        <h2>{{$voting->title}}</h2>
    </div>
    <div style="background: #ffffff;padding: 50px;max-width: 35rem;margin: auto;padding-bottom: 13px;">
        <h5>نتیحه انتخاب شما:</h5>
        @foreach ($voting->candidates as $candidate)
        <div class="form-group">
            <div class="form-row">
                <div class="col">
                    <div style="padding: 9px;border-bottom: 0.4px solid rgba(191,191,191,0.31) ;">

                        <div class="form-check" >
                            @if($vote && $vote->candidates->contains($candidate))
                                <i class="fas fa-check" style="color: rgb(99,179,103)"></i>
                            @else
                                <i class="pl-3"></i>
                            @endif
                            {{ $candidate->name }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @endforeach
    </div>
    @if($voting->visibility)
    <div style="background: #ffffff;padding: 50px;max-width: 35rem;margin: auto;padding-bottom: 13px;margin-top:3rem">
        <h5>نتیجه رای گیری:</h5>
        @foreach ($voting->candidates as $candidate)
        <div class="form-group">
            <div class="form-row">
                <div class="col">
                    <div style="padding: 9px;border-bottom: 0.4px solid rgba(191,191,191,0.31) ;">

                        <div class="form-check" >
                            {{ $candidate->name }} : {{ $candidate->votes()->count() }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @endforeach
    </div>
    @endif
    @endsection

