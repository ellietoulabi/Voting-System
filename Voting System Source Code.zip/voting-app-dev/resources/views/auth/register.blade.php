@extends('auth.layout')

@section('level1')
عضویت
@endsection
@section('listActive')
'disabled'
@endsection
@section('dashActive')
'disabled'
@endsection
@section('content')
@if(Session::has('msg'))
<div class="alert alert-success">
    {{Session::get('msg')}}
</div>
@endif
@if($errors->any())
<div class="alert alert-danger">
    <ul>
    @foreach ($errors->all() as $err)
        <li>{{$err}}</li>
    @endforeach
    </ul>
</div>
@endif
{{-- <div class="row "> --}}
<div class="heading" style="margin-bottom: 58px;">
    <h2>عضویت در سامانه</h2>
</div>
<form method='POST' action="{{route('auth.register.do')}}" style="background: #ffffff;padding: 50px;max-width: 42rem;margin-top: 0px;padding-bottom: 13px;">

    <div id="frm1">

        <label for="vTitle" class="col-2 col-form-label ">نام</label>
        <div class="">
            <input class="form-control" required type="text" name="firstname" placeholder="نام" id="vTitle">
        </div>

        <label for="vTitle" class="col-form-label mt-3">نام خوانوادگی</label>
        <div class="">
            <input class="form-control" required type="text" name="lastname" placeholder="نام خوانوادگی" id="vTitle">
        </div>

        <label for="vTitle" class="col-2 col-form-label mt-3">جنسیت</label>
        <div class="">
            <select name="gender" class="form-control">
                <option value="1">مذکر</option>
                <option value="0">مونث</option>
            </select>
        </div>

        <label for="vTitle" class="col-2 col-form-label mt-3">نام کاربری</label>
        <div class="">
            <input class="form-control" required type="text" name="username" placeholder="نام کاربری" id="vTitle">
        </div>

        <label for="vTitle" class="col-2 col-form-label mt-3">گذرواژه</label>
        <div class="">
            <input class="form-control" required type="password" name="password" placeholder="گذرواژه" id="vTitle">
        </div>

        <label for="vTitle" class="col-3 col-form-label mt-3">تکرار گذرواژه</label>
        <div class="">
            <input class="form-control" required type="password" name="password_repeat" placeholder="تکرار گذرواژه" id="vTitle">
        </div>












        <div class="form-group" style="margin-top: 56px;">
            <div class="form-row d-flex flex-row-reverse">
                <div class="col-12"><button class="btn btn-outline-success btn-block" type="submit" style="border-radius: 6px;">عضویت</button></div>
            </div>
        </div>
    </div>

</form>


{{-- </div> --}}
@endsection

