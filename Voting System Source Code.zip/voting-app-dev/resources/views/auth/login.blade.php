@extends('auth.layout')

@section('level1')
ورود به حساب کاربری
@endsection
@section('listActive')
'disabled'
@endsection
@section('dashActive')
'disabled'
@endsection
@section('content')
@if(Session::has('msg'))
<div class="alert alert-success">
    {{Session::get('msg')}}
</div>
@endif
@if($errors->any())
<div class="alert alert-danger">
    <ul>
    @foreach ($errors->all() as $err)
        <li>{{$err}}</li>
    @endforeach
    </ul>
</div>
@endif
{{-- <div class="row "> --}}
<div class="heading" style="margin-bottom: 58px;">
    <h2>ورود به حساب کاربری</h2>
</div>
 <form method='POST'  action="{{route('auth.login.do')}}" {{--action="@if(\Request::has('after')){{route('auth.login.do', ['after' => \Request::get('after')])}} @else {{route('auth.login.do')}} @endif" --}}
     style="background: #ffffff;padding: 50px;max-width: 42rem;margin-top: 0px;padding-bottom: 13px;">
    @csrf
    <div id="frm1">

        <label for="vTitle" class="col-2 col-form-label mt-3">نام کاربری</label>
        <div class="">
            <input class="form-control" required type="text" name="username" placeholder="نام کاربری" id="vTitle">
        </div>

        <label for="vTitle" class="col-2 col-form-label mt-3">گذرواژه</label>
        <div class="">
            <input class="form-control" required type="password" name="password" placeholder="گذرواژه" id="vTitle">
        </div>


        <div class="form-group pb-5" style="margin-top: 56px;">
            <div class="form-row d-flex flex-row-reverse">
                <div class="col-12"><button class="btn btn-outline-success btn-block" type="submit" style="border-radius: 6px;">ورود </button></div>
            </div>
        </div>
        <hr>

         <div class="form-note text-center " >حساب کاربری ندارید؟ <a href="{{route('auth.register.show')}}">ثبت نام کنید</a></div>

    </div>

</form>


{{-- </div> --}}
@endsection

