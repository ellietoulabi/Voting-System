$('#step1btn').click(function(){
    let candidates = [];
	let cnt = 0;
    $.each($("input[name='candidates[]']:checked"), function(){
                cnt++;
        candidates.push($(this).attr('data-v'));
    });
    if(cnt > 0) {
        $('#errAlert').hide();
        $('#step1c').addClass('passed-nav-c');
        $('#step1c').removeClass('active-nav-c');

        $('#step2c').addClass('active-nav-c');
        $('#step2c').removeClass('passive-nav-c');

        $('#frm1').hide();
        $('#frm2').show();
        console.log(candidates);
        $('#frm2c').empty();
        candidates.forEach((candidate) => {
            $('#frm2c').append(`
            <div class="form-group">
                                <div class="form-row">
                                    <div class="col">
                                        <div style="padding: 9px;border-bottom: 0.4px solid rgba(191,191,191,0.31) ;"><label>${candidate}</label></div>
                                    </div>
                                </div>
                            </div>
            `);

        });

    } else {
        $('#errAlert').show();
    }
});

$('#backBtn').click(function() {
    $('#step1c').addClass('active-nav-c');
    $('#step1c').removeClass('passed-nav-c');

    $('#step2c').addClass('passive-nav-c');
    $('#step2c').removeClass('active-nav-c');

    $('#frm1').show();
    $('#frm2').hide();
});

$(document.body).on('click', '.addCanBtn',function() {
    $(this).parent().parent().after($(this).parent().parent().clone());
});

$(document.body).on('click', '.delCanBtn',function() {
    var numItems = $('.can-row').length;
    console.log(numItems)
    if (numItems > 1) {
        $(this).parent().parent().remove();
    }
});
