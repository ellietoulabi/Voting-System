<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\VotingController as AdminVotingController;
use App\Http\Controllers\User\VotingController as UserVotingController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\Admin\BackupController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [UserVotingController::class, 'index'])->name('index');

Route::group(['prefix' => 'auth', 'as' => 'auth.'], function () {
    Route::get('/register', [AuthController::class, 'register_show'])->name('register.show');
    Route::post('/register', [AuthController::class, 'register_do'])->name('register.do');

    Route::get('/login', [AuthController::class, 'login_show'])->name('login.show');
    Route::post('/login', [AuthController::class, 'login_do'])->name('login.do');
    Route::get('/logout', [AuthController::class, 'logout'])->name('logout');
});

Route::group(['prefix' => 'user', 'as' => 'user.'], function () {
    Route::group(['prefix' => 'voting', 'as' => 'voting.'], function () {
        Route::get('{voting}/show', [UserVotingController::class, 'show'])->name('show');
        Route::post('{voting}/show', [UserVotingController::class, 'store'])->name('store');
        Route::get('/active', [UserVotingController::class, 'active'])->name('active');
        Route::get('{voting}/result', [UserVotingController::class, 'show_result'])->name('result');
        Route::get('/results', [UserVotingController::class, 'result_list'])->name('results');

    });
    Route::view('/dashboard', 'user.dashboard')->name('dashboard');
});

Route::group(['prefix' => 'admin', 'as' => 'admin.'], function () {
    Route::resource('/voting', AdminVotingController::class);
    Route::get('/voting/{voting}/result', [AdminVotingController::class, 'show_result'])->name('voting.result');

    Route::view('/dashboard', 'admin.dashboard')->name('dashboard');
    Route::get('/active', [AdminVotingController::class, 'active'])->name('active');

    Route::get('/backup', [BackupController::class, 'show'])->name('backup.show');
    Route::post('/backup', [BackupController::class, 'do'])->name('backup.do');
});
